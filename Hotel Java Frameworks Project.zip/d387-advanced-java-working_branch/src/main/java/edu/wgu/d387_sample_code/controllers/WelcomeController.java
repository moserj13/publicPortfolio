package edu.wgu.d387_sample_code.controllers;

import edu.wgu.d387_sample_code.entity.GreetingReader;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

@RestController
@RequestMapping("/greetings")
@CrossOrigin
public class WelcomeController {

    private final Executor executor = Executors.newFixedThreadPool(2);

    @GetMapping("welcome")
    public ResponseEntity<List<String>>getWelcomeMessage(){
        List<String> list = new ArrayList<>();

        executor.execute(() -> {
            GreetingReader grFR = new GreetingReader("fr", "CA");
            list.add(grFR.getWelcomeMessage());
            System.out.println("fr_CA message has been applied.");
        });

        executor.execute(() -> {
            GreetingReader grEN = new GreetingReader("en", "US");
            list.add(grEN.getWelcomeMessage());
            System.out.println("en_US message has been applied.");
        });

        return ResponseEntity.ok(list);
    }
}
