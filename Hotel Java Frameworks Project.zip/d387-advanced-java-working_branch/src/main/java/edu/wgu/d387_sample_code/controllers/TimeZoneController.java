package edu.wgu.d387_sample_code.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

@RestController
@RequestMapping("/timezone")
@CrossOrigin
public class TimeZoneController {

    final private String meetingTime = "7:30PM EST";

    final private String dateTimeFormat = "hh:mma z";

    final private String[] timeZone = new String[]{"EST", "MST", "UTC"};

    private SimpleDateFormat timeFormater = new SimpleDateFormat(dateTimeFormat);

    @GetMapping("/presentation")
    public ResponseEntity<List<String>> livePresentation(){
        List<String> presentationTime = new ArrayList<>();

        try{
            Date date = timeFormater.parse(meetingTime);

            for (String t : timeZone){
                TimeZone tz = TimeZone.getTimeZone(t);
                timeFormater.setTimeZone(tz);
                String dateOutput = timeFormater.format(date);
                presentationTime.add(dateOutput);
            }

            TimeZone tEST = TimeZone.getTimeZone("EST");
            timeFormater.setTimeZone(tEST);

            TimeZone tMST = TimeZone.getTimeZone("MST");
            timeFormater.setTimeZone(tMST);

            TimeZone tUTC = TimeZone.getTimeZone("UTC");
            timeFormater.setTimeZone(tUTC);

        } catch (Exception exception) {
            System.out.println(exception.toString());
            presentationTime.add(exception.toString());
        }
        return ResponseEntity.ok(presentationTime);
    }
}
