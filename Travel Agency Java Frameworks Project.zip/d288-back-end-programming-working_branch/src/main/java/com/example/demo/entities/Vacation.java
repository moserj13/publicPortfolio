package com.example.demo.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "vacations")
@Getter
@Setter
//@NoArgsConstructor
//@AllArgsConstructor

public class Vacation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "vacation_id")
    @JsonProperty("id")
    private Long vacation_id;

    @CreationTimestamp
    @Column(name = "create_date")
    @JsonProperty("create_date")
    private Date create_date;

    @Column(name = "description")
    @JsonProperty("description")
    private String description;

    @Column(name = "image_url")
    @JsonProperty("image_URL")
    private String image_url;

    @UpdateTimestamp
    @Column(name = "last_update")
    @JsonProperty("last_update")
    private Date last_update;

    @Column(name = "travel_fare_price")
    @JsonProperty("travel_price")
    private Double travel_fare_price;

    @Column(name = "vacation_title")
    @JsonProperty("vacation_title")
    private String vacation_title;

    @OneToMany(mappedBy = "vacation", cascade = CascadeType.ALL)
    private Set<Excursion> excursions;
}
