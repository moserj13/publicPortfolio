package com.example.demo;

import com.example.demo.dao.CustomerRepository;
import com.example.demo.dao.DivisionRepository;
import com.example.demo.entities.Customer;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class BootStrapData {

        @Autowired
        private CustomerRepository customerRepository;

        @Autowired
        private DivisionRepository divisionRepository;

        @PostConstruct
        public void loadInitialData() {

            if(customerRepository.count() == 1) {



                Customer customer1 = new Customer();
                customer1.setCustomer_first_name("Jack");
                customer1.setCustomer_last_name("Frost");
                customer1.setPostal_code("80212");
                customer1.setAddress("222 Street");
                customer1.setPhone("(123)456-7890");
                customer1.setDivision(divisionRepository.findAll().get(7));
                customer1.setCreate_date(new Date());
                customer1.setLast_update(new Date());

                Customer customer2 = new Customer();
                customer2.setCustomer_first_name("Joe");
                customer2.setCustomer_last_name("Blow");
                customer2.setPostal_code("80213");
                customer2.setAddress("321 Lane");
                customer2.setPhone("(720)555-5000");
                customer2.setDivision(divisionRepository.findAll().get(7));
                customer2.setCreate_date(new Date());
                customer2.setLast_update(new Date());

                Customer customer3 = new Customer();
                customer3.setCustomer_first_name("Ben");
                customer3.setCustomer_last_name("Ten");
                customer3.setPostal_code("80231");
                customer3.setAddress("123 Nowhere");
                customer3.setPhone("(111)222-3333");
                customer3.setDivision(divisionRepository.findAll().get(5));
                customer3.setCreate_date(new Date());
                customer3.setLast_update(new Date());

                Customer customer4 = new Customer();
                customer4.setCustomer_first_name("Who");
                customer4.setCustomer_last_name("WHOOO");
                customer4.setPostal_code("90326");
                customer4.setPhone("(254)758-1345");
                customer4.setAddress("1022 BirdCall ln");
                customer4.setDivision(divisionRepository.findAll().get(2));
                customer4.setCreate_date(new Date());
                customer4.setLast_update(new Date());

                Customer customer5 = new Customer();
                customer5.setCustomer_first_name("Justin");
                customer5.setCustomer_last_name("Stand");
                customer5.setPostal_code("38092");
                customer5.setAddress("145 Here");
                customer5.setPhone("(303)000-1456");
                customer5.setDivision(divisionRepository.findAll().get(3));
                customer5.setCreate_date(new Date());
                customer5.setLast_update(new Date());

                customerRepository.save(customer1);
                customerRepository.save(customer2);
                customerRepository.save(customer3);
                customerRepository.save(customer4);
                customerRepository.save(customer5);

                System.out.println("Five customers were added to the DataBase!");
            } else {
                System.out.println("Five customers were already in the DataBase!");
            }
        }
    }


