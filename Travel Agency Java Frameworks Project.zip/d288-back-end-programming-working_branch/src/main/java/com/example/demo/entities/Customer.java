package com.example.demo.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import org.antlr.v4.runtime.misc.NotNull;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import jakarta.persistence.*;
import org.springframework.lang.NonNullFields;

import java.util.Date;
import java.util.List;
import java.util.Set;




@Entity
@Table(name = "customers")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Customer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "customer_id")
    @JsonProperty("id")
    private Long customer_id;


    @JsonProperty("firstName")
    @Column(name = "customer_first_name", nullable = false)
    private String customer_first_name;


    @JsonProperty("lastName")
    @Column(name = "customer_last_name", nullable = false)
    private String customer_last_name;

    @NonNull
    @JsonProperty("address")
    @Column(name = "address", nullable = false)
    private String address;

    @NonNull
    @JsonProperty("postal_code")
    @Column(name = "postal_code", nullable = false)
    private String postal_code;

    @NonNull
    @JsonProperty("phone")
    @Column(name = "phone", nullable = false)
    private String phone;

    @CreationTimestamp
    @Column(name = "create_date")
    private Date create_date;

    @UpdateTimestamp
    @Column(name = "last_update")
    private Date last_update;

    @ManyToOne
    @JoinColumn(name = "division_id")
    private Division division;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Set<Cart> carts;

}
