# Jonathan Moser  ID: 011634866
# 4/16/24

# My imports.
import csv
from datetime import datetime, timedelta, time
from Driver import Driver
from LinearHashTable import HashTable
from Package import Package
from Truck import Truck

# Global constants used for trucks and drivers.
num_trucks = 3
num_drivers = 2


# Parse the package info out of the CSV file.
# O(N)
def open_package_data(ht):
    # CSV Reader.
    with open('packages.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')

        # Read the info from the CSV file.
        for row in csv_reader:
            # Store the data for packages.
            id_number = int(row[0])
            delivery_address = row[1]
            delivery_city = row[2]
            delivery_state = row[3]
            delivery_zip = row[4]
            delivery_deadline = row[5]
            package_mass = row[6]
            special_notes = row[7]
            delivery_status = "At the hub!"

            package = Package(id_number, delivery_address, delivery_city, delivery_state, delivery_zip,
                              delivery_deadline, package_mass,
                              special_notes, delivery_status)
            # Add the package to the hash table.
            ht.insert(package)


# Parse the package info out of the CSV file.
# O(N^2)
def open_distance_data():
    # CSV Reader.
    with open('distances.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')

        # Create a list for the data.
        num_addresses = total_addresses()
        distance_data = [[0 for x in range(num_addresses)] for y in range(num_addresses)]

        src_address_index = 0
        # Parse the address data.
        for src_address in csv_reader:
            for dest_address_index in range(num_addresses):
                if src_address[dest_address_index] != '':
                    distance_data[src_address_index][dest_address_index] = float(src_address[dest_address_index])
                    distance_data[dest_address_index][src_address_index] = float(src_address[dest_address_index])
            src_address_index = src_address_index + 1
        # Return the distance list.
        return distance_data


# Create a list of addresses from the CSV file.
# O(N)
def open_address_data():
    # CSV Reader.
    with open('addresses.csv') as csv_file:
        address_list = []
        csv_reader = csv.reader(csv_file, delimiter=',')

        # Parse each row of data.
        for row_text in csv_reader:
            full_address = row_text[0].split("\n")
            street_address = full_address[1].strip()
            address_list.append(street_address)
    # Return the list of addresses.
    return address_list


# This gives the total number of addresses from the CSV file.
# O(N)
def total_addresses():
    num_addresses = 0
    # CSV Reader.
    with open('addresses.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')

        # Count the rows in the CSV file to find the total.
        for row in csv_reader:
            num_addresses = num_addresses + 1
    # Return the total addresses
    return num_addresses


# Calculate the distance from one address to another.
# O(1)
def distance_from(address1, address2):
    distance_list = open_distance_data()
    address_list = open_address_data()

    # Index the addresses
    address1_index = address_list.index(address1)
    address2_index = address_list.index(address2)
    # Return the distance between the two addresses.
    return distance_list[address1_index][address2_index]


# This sets drivers with trucks.
# O(N)
def drivers_to_trucks(num_trucks, num_drivers):
    truck_list = []
    driver_list = []

    # Drivers stay with trucks, so this variable is set to the minimum for drivers -> trucks.
    num_trucks_drivers = min(num_trucks, num_drivers)

    # Initialize the Trucks
    for current_truck_num in range(1, num_trucks_drivers + 1, 1):
        truck_id = current_truck_num
        truck = Truck(truck_id)
        truck_list.append(truck)

    # Initialize the Drivers
    for current_driver_num in range(1, num_trucks_drivers + 1, 1):
        driver_id = current_driver_num
        driver = Driver(driver_id)
        driver.assign_truck(truck_list)
        driver_list.append(driver)
    # Return the lists of trucks and drivers.
    return truck_list, driver_list


# This assigns packages to the trucks until all packages are gone or the truck fills up.
# O(N^4)
def assign_packages(ht, truck):
   # current_time = datetime.now().time()
   # target_time = time(hour=10, minute=20)

    while len(find_assignable_packages(ht, truck)) > 0 and not truck.is_full() and truck.at_hub is True:
        # Set the address to the hub address if there aren't packages.
        if len(truck.package_id_list) == 0:
            address = truck.hub_address
        else:
            num_packages_in_truck = len(truck.package_id_list)
            last_package_added_id = truck.package_id_list[num_packages_in_truck - 1]
            last_package_added = ht.lookup(last_package_added_id)
            address = last_package_added.delivery_address

        # Set the closest package as the last address.
        # O(N)
        closest_package = closest_package_in_list(address, find_assignable_packages(ht, truck))
        truck.assign_package(closest_package)

        # Code to fix package 9's wrong address.
        # O(N)
        if closest_package.id_number == 9:
            closest_package.delivery_address = "410 S State St"
            closest_package.delivery_city = "Salt Lake City"
            closest_package.delivery_state = "UT"
            closest_package.delivery_zip = "84111"
            sort_package_list(ht, truck)

        # Add associated packages to the same truck.
        # O(N^3)
        for list in find_associated_packages(ht):
            if closest_package in list:
                for associated_package in list:
                    if associated_package.is_truck_assigned() is False:
                        truck.assign_package(associated_package)

        # Code call to the sort function.
        sort_package_list(ht, truck)


# Sort the packages on a truck to maintain an optimal route.
# O(N^2)
def sort_package_list(ht, truck):
    sorted_package_id_list = []
    current_address = truck.hub_address
    package_list = truck.get_package_list(ht)

    # Add the packages based on the shortest distance between them.
    while len(package_list) != 0:
        nearest_package = closest_package_in_list(current_address, package_list)
        sorted_package_id_list.append(nearest_package.id_number)
        current_address = nearest_package.delivery_address
        package_list.remove(nearest_package)
    # Sort the package list.
    truck.package_id_list = sorted_package_id_list


# Search for the closest package from the current address.
# O(N)
def closest_package_in_list(current_address, package_list):
    # Variables to store the nearest Package
    nearest_package = None
    nearest_package_distance = None

    # Find the package with the shortest distance from the last delivery.
    for package in package_list:
        if package is not None:
            if nearest_package is None:
                nearest_package = package
                nearest_package_address = nearest_package.delivery_address
                nearest_package_distance = distance_from(nearest_package_address, current_address)
            else:
                package_address = package.delivery_address
                package_distance = distance_from(package_address, current_address)

                # Check distance between packages.
                if package_distance < nearest_package_distance:
                    nearest_package = package
                    nearest_package_distance = package_distance
    # Show the address of the next package.
    return nearest_package


# Deliver the packages until they're all gone.
# O(N^5)
def deliver_the_packages(ht, truck_list):
    while not packages_were_delivered(ht):
        for truck in truck_list:
            # Set the packages on the truck to "En route".
            truck.set_packages_en_route(ht)

            current_address = truck.hub_address
            current_package_index = 0

            # Deliver the packages.
            while len(truck.package_id_list) > 0:
                # Mark the package as "Delivered".
                package_id = truck.package_id_list[current_package_index]
                package = ht.lookup(package_id)

                # Add the miles to the total milage.
                distance_traveled = distance_from(current_address, package.delivery_address)
                truck.deliver_package(ht, package_id, distance_traveled)

                # Set the delivered package address as the new address.
                current_address = package.delivery_address

            # Return the truck to the hub.
            truck.send_back_to_hub(distance_from(current_address, truck.hub_address))
        # Load the truck again.
        for truck in truck_list:
            assign_packages(ht, truck)


# Check if all the packages were delivered.
# O(N)
def packages_were_delivered(ht):
    for package in ht.package_table:
        if package is not None and package.delivery_timestamp is None:
            return False
    # Confirm delivery is complete.
    return True


# Check for unassigned packages in the hash table.
# O(N)
def find_unassigned_packages(ht):
    unassigned_packages = []

    for package in ht.package_table:
        if package is not None and package.is_truck_assigned() is False:
            unassigned_packages.append(package)
    # Return the list of unassigned packages.
    return unassigned_packages


# Check for assignable packages.
# O(N^3)
def find_assignable_packages(ht, truck):
    # Check for packages that can't be assigned.
    # Create a list of packages that can be assigned.
    unassignable_packages = find_unassignable_packages(ht, truck)
    assignable_packages = []

    for package in find_unassigned_packages(ht):
        if package is not None and package not in unassignable_packages:
            assignable_packages.append(package)
    # Return the list of assignable packages.
    return assignable_packages


# Check for packages that can't be assigned to this truck.
# O(N^3)
def find_unassignable_packages(ht, truck):
    unassignable_packages = []
    associated_package_lists = find_associated_packages(ht)

    for package in ht.package_table:
        if package is not None:
            if package.is_truck_assigned():
                unassignable_packages.append(package)
            # Add wrong truck packages to the unassignable list.
            elif package.find_required_truck_id() is not None and package.find_required_truck_id() is not truck.id:
                unassignable_packages.append(package)
                # Add associated packages to the unassignable list.
                if len(associated_package_lists) > 0:
                    for list in associated_package_lists:
                        if package in list:
                            for associated_package in list:
                                if associated_package not in unassignable_packages:
                                    unassignable_packages.append(associated_package)

            # Prevent delayed packages from being assigned to a truck.
            elif package.find_delayed_arrival_time() is not None and package.find_delayed_arrival_time() > truck.time_obj:
                if package not in unassignable_packages:
                    unassignable_packages.append(package)
    # Return the list of unassignable packages.
    return unassignable_packages


# Create a list of associated packages for delivery.
# O(N^3)
def find_associated_packages(ht):
    # List of associated package lists that contain Packages that must be delivered together
    associated_packages_lists = []

    # Combine associated package lists.
    # O(N^3)
    for current_package in ht.package_table:
        if current_package is not None and "Must be delivered with" in current_package.special_notes:
            associated_packages = find_direct_association_packages(ht, current_package)
            # Combine lists
            combine_lists = False
            list_to_combine = None

            # Check for a list with the package and append the results.
            # O(N^2)
            if len(associated_packages_lists) > 0:
                for package in associated_packages:
                    for list in associated_packages_lists:
                        if package in list:
                            combine_lists = True
                            list_to_combine = list
                            break

            # Add to an existing list instead of making a new one.
            # O(N)
            if combine_lists:
                for package in associated_packages:
                    if package not in list_to_combine:
                        list_to_combine.append(package)
            # Create a new list if one doesn't exist.
            else:
                associated_packages_lists.append(associated_packages)
    # Show the new list of associated packages.
    return associated_packages_lists


# Use the special notes to find associated packages.
# O(N^2)
def find_direct_association_packages(ht, package):
    if "Must be delivered with" in package.special_notes:
        associated_packages = [package]
        # Search for special notes requiring package association.
        special_notes_no_commas = package.special_notes.replace(",", " ")
        tokenized_special_notes = special_notes_no_commas.split()
        package_ids_list = [int(i) for i in tokenized_special_notes if i.isdigit()]

        # Append the additional packages for delivery.
        for package_id in package_ids_list:
            package = ht.lookup(package_id)
            associated_packages.append(package)
            additional_packages = find_direct_association_packages(ht, package)

            if additional_packages is not None:
                for additional_package in additional_packages:
                    if additional_package not in associated_packages:
                        associated_packages.append(additional_package)
        # Return the list of associated packages.
        return associated_packages


# This is my main menu display.
def user_menu(ht, truck_list):
    # Display the title of the application
    print("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-")
    print("Western Governors University Parcel Service")
    print("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-")

    # User menu.
    print("Select an option from the menu. You can generate a report, or check on a package.\n")
    print("-+-+-+-+-+-+-+-+-+-+-+-+-+-+")
    print("\t1. Generate A Report")
    print("\t2. Check On A Package")
    print("\t3. Quit")
    print("-+-+-+-+-+-+-+-+-+-+-+-+-+-+")
    valid_options = [1, 2, 3]

    # Default option.
    option = None

    # Ask for user input.
    while option is None:
        user_input = input("\nChoose An Option From The Menu: ")

        if user_input.isdigit() and int(user_input) in valid_options:
            option = int(user_input)
        else:
            print("Please Choose A valid Option!")

    # Check the option.
    if option == 1: general_report(ht, truck_list)
    if option == 2: check_a_package(ht, truck_list)
    if option == 3:
        print("Goodbye!")
        quit()


# Prompt user input for time then display the report.
def general_report(ht, truck_list):
    report_datetime = prompt_time()

    # Display the status of the Packages.
    print("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-")
    print("Status of all the packages: " + report_datetime.strftime("%I:%M %p"))
    print("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-")

    # Print out the package info at the requested time.
    for package in range(1, len(ht.package_table) + 1):
        if package is not None:
            display_packages(ht, package, report_datetime)

    print_total_miles(truck_list, report_datetime)

    # Return to user menu.
    user_menu(ht, truck_list)


# Show the total miles for the trucks at the requested time.
def print_total_miles(truck_list, report_datetime):
    report_timedelta = timedelta(hours=report_datetime.hour, minutes=report_datetime.minute)
    total_miles = 0

    # Find the truck's distance.
    for truck in truck_list:
        if len(truck.miles_timestamp) > 0:
            index = len(truck.miles_timestamp) - 1

            while index > 0:
                timestamp_miles = truck.miles_timestamp[index][0]
                timestamp_delta = truck.miles_timestamp[index][1]

                if timestamp_delta <= report_timedelta:
                    total_miles += timestamp_miles
                    print("Truck %d: %0.2f miles" % (truck.id, timestamp_miles))
                    break
                else:
                    index = index - 1
            if index == 0:
                print("Truck %d: %0.2f miles" % (truck.id, 0.00))
    print("\nTotal miles for all trucks at " + report_datetime.strftime("%I:%M %p") + ": %0.2f miles" %
          total_miles)


# Check a package.
def check_a_package(ht, truck_list):
    report_datetime = prompt_time()
    package_id = package_id_prompt(ht)

    # Show package info at requested time.
    print("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-")
    print("Showing package info at: " + report_datetime.strftime("%I:%M %p"))
    print("-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-")
    display_packages(ht, package_id, report_datetime)

    # Menu prompt.
    user_menu(ht, truck_list)


# Show info about a specific package.
def display_packages(ht, package_id, report_datetime):
    package = ht.lookup(package_id)
    report_timedelta = timedelta(hours=report_datetime.hour, minutes=report_datetime.minute)

    # Create a package print string.
    print_package = "|Package ID: %d| " % package.id_number

    # Show the delivery status.
    if package.en_route_timestamp > report_timedelta:
        print_package += "\tPackage Status: At the hub!"
    elif package.delivery_timestamp > report_timedelta:
        delivery_timestamp_datetime = datetime.strptime(str(package.delivery_timestamp), "%H:%M:%S")
        print_package += "\tPackage Status: En route, delivery expected at " + delivery_timestamp_datetime.strftime(
            "%I:%M %p")
    else:
        delivery_timestamp_datetime = datetime.strptime(str(package.delivery_timestamp), "%H:%M:%S")
        print_package += "\tPackage Status: Delivered at " + delivery_timestamp_datetime.strftime("%I:%M %p")
    # Delivery info.
    current_time = report_datetime.time()
    target_time = time(hour=10, minute=20)
    if package.id_number == 9 and current_time < target_time:
        print_package += "\tAddress: " + "300 State St, Salt Lake City, UT 84103"
        print_package += "\tCity: " + package.delivery_city
        print_package += "\tZIP Code: " + package.delivery_zip
        print_package += "\tPackage Weight: " + package.package_weight + " kilos"
        print_package += "\tDelivery Deadline: " + package.delivery_deadline
        print_package += "\tOn Truck: " + str(package.assigned_truck_id)

    elif package.id_number == 9 and current_time >= target_time:
        print_package += "\t(Updated Address) " + "410 S State St, Salt Lake City, UT 84111"
        print_package += "\tCity: " + package.delivery_city
        print_package += "\tZIP Code: " + package.delivery_zip
        print_package += "\tPackage Weight: " + package.package_weight + " kilos"
        print_package += "\tDelivery Deadline: " + package.delivery_deadline
        print_package += "\tOn Truck: " + str(package.assigned_truck_id)

    else:
        print_package += "\tAddress: " + package.delivery_address
        print_package += "\tCity: " + package.delivery_city
        print_package += "\tZIP Code: " + package.delivery_zip
        print_package += "\tPackage Weight: " + package.package_weight + " kilos"
        print_package += "\tDelivery Deadline: " + package.delivery_deadline
        print_package += "\tOn Truck: " + str(package.assigned_truck_id)

    # Print the package info to the screen.
    print(print_package)


# Report time prompt.
def prompt_time():
    report_datetime = None

    # Ask for a time.
    while report_datetime is None:
        try:
            report_datetime = datetime.strptime(
                input("Enter a report time. Use the following format: |HOUR:MINUTE AM/PM| "), "%I:%M %p")
        except:
            print("\tInvalid formatting. Please try again!\n")
    # Show the report's date and time.
    return report_datetime


# Ask for a package ID.
def package_id_prompt(ht):
    package_id = None
    while package_id is None:
        user_input = input("Enter a package ID to view the report: ")

        if user_input.isdigit():
            if ht.lookup(int(user_input)) is not None:
                package_id = int(user_input)
            else:
                print("\tNo packages were found with that ID!\n")
        else:
            print("\tInvalid formatting. Please try again!\n")
    # Show the package ID.
    return package_id


# This is the main class of the program.
def main():
    # Load the packages into the table.

    delivery_ht = HashTable()
    delivery_ht.clear()
    open_package_data(delivery_ht)

    # Initialize the drivers to trucks.
    truck_list, driver_list = drivers_to_trucks(num_trucks, num_drivers)

    # Check for delayed packages.
    delayed_start_time = None

    for package in delivery_ht.package_table:
        if package is not None and package.find_delayed_arrival_time() is not None:
            if delayed_start_time is None or delayed_start_time > package.find_delayed_arrival_time():
                delayed_start_time = package.find_delayed_arrival_time()
    if len(truck_list) > 1:
        last_truck_index = len(truck_list) - 1
        truck_list[last_truck_index].time_obj = delayed_start_time

    # Assign trucks with packages.
    for truck in truck_list:
        assign_packages(delivery_ht, truck)

    # Deliver the packages!
    deliver_the_packages(delivery_ht, truck_list)

    # User menu.
    user_menu(delivery_ht, truck_list)


# Call the script until the user exits the program.
if __name__ == "__main__":
    main()
