# My imports.
# Jonathan Moser  ID: 011634866
# 4/16/24

# My imports
from datetime import timedelta


# Class for the trucks.
class Truck:
    # Constants for the truck class.
    average_speed = 18
    max_packages = 16

    # General truck constructor class.
    def __init__(self, truck_id, mph=average_speed, max_packages=max_packages):
        self.id = truck_id
        self.package_id_list = []
        self.mph = mph
        self.max_packages = max_packages
        self.total_distance = 0
        self.miles_timestamp = []
        self.driver = None
        self.time_obj = timedelta(hours=8, minutes=0, seconds=0)
        self.hub_address = "4001 South 700 East"
        self.at_hub = True

    # Add packages to the list for a truck.
    def assign_package(self, package):
        if len(self.package_id_list) < self.max_packages:
            self.package_id_list.append(package.id_number)
            package.assigned_truck_id = self.id
        else:
            # Show unsuccessful assignment.
            return False

    # Set packages to "En route" when they are on the truck.
    # O(N)
    def set_packages_en_route(self, ht):
        for package_id in self.package_id_list:
            package = ht.lookup(package_id)
            package.delivery_status = "En route"
            package.en_route_timestamp = self.time_obj

    # Deliver the Packages.
    def deliver_package(self, ht, package_id, distance_traveled):
        package = ht.lookup(package_id)
        self.package_id_list.remove(package_id)
        self.at_hub = False
        self.add_miles(distance_traveled)
        self.time_obj += timedelta(minutes=(distance_traveled / self.mph * 60))
        self.miles_timestamp.append([self.total_distance, self.time_obj])
        package.delivery_status = "Delivered!"
        package.delivery_timestamp = self.time_obj

    # Send the truck back to the hub and update the distance / time values.
    def send_back_to_hub(self, distance_from_hub):
        self.add_miles(distance_from_hub)
        self.time_obj += timedelta(minutes=(distance_from_hub / self.mph * 60))
        self.miles_timestamp.append([self.total_distance, self.time_obj])
        self.at_hub = True

    # Add the miles to the total distance.
    def add_miles(self, miles):
        self.total_distance = self.total_distance + miles

    # Show a list of associated packages for the truck.
    def get_package_list(self, ht):
        packages_list = []

        for package_id in self.package_id_list:
            packages_list.append(ht.lookup(package_id))
        # Return a list of packages for the truck.
        return packages_list

    # Check if the truck is carrying the maximum number of packages.
    def is_full(self):
        if len(self.package_id_list) == self.max_packages:
            return True
        # Check if the truck is now full.
        return False
