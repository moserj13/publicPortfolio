# Jonathan Moser  ID: 011634866
# 4/16/24

class Driver:
    # Initialize the driver with an ID number.
    def __init__(self, driver_id):
        self.driver_id = driver_id
        self.truck = None

    # Assign a driver to a truck and check for success.
    def assign_truck(self, truck_list):
        # Find an unassigned Truck to assign to the Driver
        for truck in truck_list:
            if truck.driver is None:
                truck.driver = self
                self.truck = truck
                return True
        # Check for success or failure.
        return False

    # Unassign a driver from a truck.
    def remove_truck(self):
        self.truck.driver = None
        self.truck = None
