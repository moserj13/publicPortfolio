# Jonathan Moser  ID: 011634866
# 4/16/24

# My imports.
from datetime import datetime, timedelta


# This is my package constructor.
class Package:
    def __init__(self, id_number, delivery_address, delivery_city, delivery_state, delivery_zip, delivery_deadline,
                 package_weight, special_notes, delivery_status):
        self.id_number = id_number
        self.delivery_address = delivery_address
        self.delivery_city = delivery_city
        self.delivery_state = delivery_state
        self.delivery_zip = delivery_zip
        self.delivery_deadline = delivery_deadline
        self.package_weight = package_weight
        self.special_notes = special_notes
        self.delivery_status = delivery_status
        self.assigned_truck_id = None
        self.on_truck = False
        self.en_route_timestamp = None
        self.delivery_timestamp = None

    # CHeck if a package has been assigned to a truck.
    def is_truck_assigned(self):
        if self.assigned_truck_id is None:
            return False
        return True

    # Find the truck ID for special notes.
    def find_required_truck_id(self):
        if "Can only be on truck" in self.special_notes:
            specified_truck_id = [int(i) for i in self.special_notes.split() if i.isdigit()][0]
            return specified_truck_id
        return None

    # Find the delayed arrival time of a package.
    def find_delayed_arrival_time(self):
        if "Delayed on flight---will not arrive to depot until" in self.special_notes:
            tokenized_special_notes = self.special_notes.split()
            for token in tokenized_special_notes:
                try:
                    # Assign a time for the delayed package.
                    timestamp = datetime.strptime(token, "%H:%M")
                    delayed_arrival = timedelta(hours=timestamp.hour, minutes=timestamp.minute)
                    return delayed_arrival
                except:
                    pass
        # Packages with the wrong address will be treated as delayed packages.
        if "Wrong address listed" in self.special_notes:
            delayed_arrival = timedelta(hours=10, minutes=20)
            return delayed_arrival
        return None

    # Return a timedelta for delivery_deadline.
    def find_delivery_deadline_timedelta(self):
        tokenized_special_notes = self.delivery_deadline.split()
        for token in tokenized_special_notes:
            try:
                # Assign a delivery deadline for a package.
                timestamp = datetime.strptime(token, "%H:%M")
                delivery_deadline = timedelta(hours=timestamp.hour, minutes=timestamp.minute)
                return delivery_deadline
            except:
                pass
