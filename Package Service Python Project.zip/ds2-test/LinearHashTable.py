# Jonathan Moser  ID: 011634866
# 4/16/24
# This is my hash table.

class HashTable:
    # I am implementing linear probe hashing.
    # O(initial_capacity)
    def __init__(self, initial_capacity=40):
        self.initial_capacity = initial_capacity
        self.package_table = [None] * initial_capacity
        self.bucket_status_table = ["EMPTY_SINCE_START"] * initial_capacity

    def clear(self):
        # Reset package_table and bucket_status_table to initial state
        self.package_table = [None] * self.initial_capacity
        self.bucket_status_table = ["EMPTY_SINCE_START"] * self.initial_capacity
    # Insert a new item into the hash table by using the item ID number.
    def insert(self, package):
        N = len(self.package_table)
        bucket = hash(package.id_number) % N

        # Linear probing step.
        #O(N)
        for i in range(N):
            # Check if the current bucket is occupied.
            if self.bucket_status_table[bucket] in ["EMPTY_SINCE_START", "EMPTY_AFTER_REMOVAL"]:
                self.package_table[bucket] = package
                self.bucket_status_table[bucket] = "OCCUPIED"
                return True
            elif self.package_table[bucket] is not None and self.package_table[bucket].id_number == package.id_number:
                # Check for duplicate values, return a message if there are any.
                raise ValueError(f"Duplicate key found: {package.id_number}")

            # Step to the next bucket by incrementing by 1.
            bucket = (bucket + 1) % N

        # Return false if the hash table is full.
        return False

    # Check for an item by using the item ID as a key.
    def lookup(self, key):
        N = len(self.package_table)
        bucket = hash(key) % N

        # Linear probing step.
        for i in range(N):
            # The key cannot be in an empty bucket.
            if self.bucket_status_table[bucket] == "EMPTY_SINCE_START":
                return None

            # Check the bucket for a key.
            if self.package_table[bucket] is not None and self.package_table[bucket].id_number == key:
                return self.package_table[bucket]

            # Step to the next bucket index.
            bucket = (bucket + 1) % N

        # Return None if the key cannot be found.
        return None
