package com.example.demo.domain;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import java.util.Set;

@Entity
@DiscriminatorValue("2")
public class OutsourcedPart extends Part {

    private String companyName;

    // Define a field to represent the associated product
    private Product product;

    public OutsourcedPart() {
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    // Getter and setter for the associated product
    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public boolean isInvValid() {
        return this.inv >= this.minInv && this.inv <= this.maxInv;
    }
}
