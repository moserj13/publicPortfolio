package com.example.demo.repositories;

import com.example.demo.domain.InhousePart;
import org.springframework.data.repository.CrudRepository;

import java.util.Optional;

/**
 *
 *
 *
 *
 */
public interface InhousePartRepository extends CrudRepository<InhousePart,Long> {
    Optional<InhousePart> findByName(String name);
}
