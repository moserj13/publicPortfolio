package com.example.demo.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PartsPurchasePageController {

    @GetMapping("/part_success")
    public String success() {
        return "success";
    }

    @GetMapping("/part_error")
    public String error() {
        return "error";
    }
}