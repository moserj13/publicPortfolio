package com.example.demo.bootstrap;

import com.example.demo.domain.InhousePart;
import com.example.demo.domain.Product;
import com.example.demo.repositories.InhousePartRepository;
import com.example.demo.repositories.PartRepository;
import com.example.demo.repositories.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;

@Transactional
@Component
public class BootStrapData implements CommandLineRunner {

    protected final PartRepository partRepository;
    protected final ProductRepository productRepository;
    protected final InhousePartRepository inhousePartRepository;

    public BootStrapData(PartRepository partRepository, ProductRepository productRepository,
                         InhousePartRepository inhousePartRepository) {
        this.partRepository = partRepository;
        this.productRepository = productRepository;
        this.inhousePartRepository = inhousePartRepository;
    }

    @Override
    public void run(String... args) throws Exception {
        setUpParts();
        setUpProducts();
        printBootstrapInfo();
    }

    private void setUpParts() {
        setUpInhousePart("50mm Wheels x 4", 5, 20.0, 1, 100);
        setUpInhousePart("75mm Wheels x 4", 3, 25.0, 2, 60);
        setUpInhousePart("100mm Wheels x 4", 15, 30.0, 1, 75);
        setUpInhousePart("Grippy Wheels x 4", 7, 23.0, 4, 50);
        setUpInhousePart("Soft Wheels x 4", 9, 21.0, 3, 80);
    }

    private void setUpInhousePart(String name, int inv, double price, int minInv, int maxInv) {
        InhousePart part = inhousePartRepository.findByName(name).orElseGet(() -> {
            InhousePart newPart = new InhousePart();
            newPart.setName(name);
            return newPart;
        });
        part.setInv(inv);
        part.setPrice(price);
        part.setMinInv(minInv);
        part.setMaxInv(maxInv);
        inhousePartRepository.save(part);
    }

    private void setUpProducts() {
        setUpProduct("Skateboard", 75.0, 20);
        setUpProduct("Longboard", 100.0, 15);
        setUpProduct("Mountainboard", 250.0, 5);
        setUpProduct("Tinyboard", 30.0, 10);
        setUpProduct("Cruiser", 120.0, 12);
    }

    private void setUpProduct(String name, double price, int inv) {
        Product product = productRepository.findByName(name).orElseGet(() -> {
            Product newProduct = new Product();
            newProduct.setName(name);
            return newProduct;
        });
        product.setPrice(price);
        product.setInv(inv);
        productRepository.save(product);
    }

    private void printBootstrapInfo() {
        System.out.println("Started in Bootstrap");
        System.out.println("Number of Products: " + productRepository.count());
        productRepository.findAll().forEach(System.out::println);
        System.out.println("Number of Parts: " + partRepository.count());
        partRepository.findAll().forEach(System.out::println);
    }
}


